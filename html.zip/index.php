<html>
<head>
	<meta charset="UTF-8">
	<title>Dynamic Website;!</title>
	<link rel="stylesheet" href="style.css">
</head>

<body class="bodyStyle">

	<div id="header" class="mainHeader">
		<hr>
		<div class="center"><H1>Dynamic Website</H1></div>
	</div>
	<br>
	<hr>
	<div class="topnav">
        <p>Query data is provided by the link below</p>
		<a href="query.php">Query</a>
	</div>
	<hr>
	<div id="mainContent">

		<div id="mainPictures" class="center">

			<hr>
			<p>Welcome to the dynamic website created for Assignment 2 </p>
			<br>
			<div class="firstPic"><img src="https://topdev.vn/blog/wp-content/uploads/2020/10/image1.png" height="400" width=auto></div>
			<table>
				<tr>
				    <td>
						<div class="cursiveText">The following data is provided at the courtesy of AWS.</div>
						<div class="cursiveText">And here are some random texts to come along with it: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin pretium nisi ut porttitor semper. In faucibus semper venenatis. Proin est elit, eleifend a est et, dapibus consequat leo. Integer libero mauris, molestie ac nulla in, vestibulum tempor felis. Integer at sodales quam. Nunc enim libero, vestibulum imperdiet luctus in, vestibulum ac ante. Vestibulum malesuada purus sit amet finibus tincidunt. Sed cursus pulvinar vehicula. Proin ac feugiat diam, eu luctus dolor. Fusce nec volutpat elit. Suspendisse sit amet diam fringilla, volutpat ante quis, tempus orci. Duis pulvinar pharetra enim, egestas auctor mi bibendum in..</div>
					</td>
				</tr>
			</table>
			<hr>
		</div>
	</div>

	<div id="aboutUs" class="center">
		<hr>
		<div>
			<h2>About Us</h2>
		</div>
			<table>
				<tr>
					<td><figure><img src="Shirley.jpeg" height=auto width="200"><figcaption>Random Picture of Woman</figcaption></figure></td>
				</tr>
					<tr><td><p>Our site got started because it was a requirement of Assignment 2 <br>The random woman in the picture above have nothing to do with my shoddy work. </p></td>
				</tr>
			</table>
			<hr>
		</div>
</body>
</html>
